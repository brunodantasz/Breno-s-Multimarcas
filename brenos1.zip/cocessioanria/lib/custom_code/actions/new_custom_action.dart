// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future newCustomAction() async {
  // create new page with description, image and price
// Define the variables for the description, image and price
  String description = "This is a new product";
  String imageUrl = "https://example.com/image.jpg";
  double price = 9.99;

// Create a new page with a Scaffold widget
  await Navigator.of(context).push(MaterialPageRoute(
    builder: (BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: Text("New Product"),
        ),
        body: Column(
          children: [
            // Display the image
            Image.network(imageUrl),
            // Display the description
            Text(description),
            // Display the price
            Text("Price: \$${price.toStringAsFixed(2)}"),
          ],
        ),
      );
    },
  ));
}
