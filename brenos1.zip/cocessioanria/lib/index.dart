// Export pages
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/pesquisaa/pesquisaa_widget.dart' show PesquisaaWidget;
export '/pages/fit/fit_widget.dart' show FitWidget;
export '/pages/cruze/cruze_widget.dart' show CruzeWidget;
export '/pages/a1/a1_widget.dart' show A1Widget;
export '/pages/x3/x3_widget.dart' show X3Widget;
export '/pages/compass/compass_widget.dart' show CompassWidget;
export '/pages/kicks/kicks_widget.dart' show KicksWidget;
export '/contato/contato_widget.dart' show ContatoWidget;
export '/login/login_widget.dart' show LoginWidget;
export '/admin/admin_widget.dart' show AdminWidget;
export '/pesquisa/pesquisa_widget.dart' show PesquisaWidget;
export '/homee2/homee2_widget.dart' show Homee2Widget;
