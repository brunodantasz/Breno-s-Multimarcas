import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyB3FADUnddxHQHB1SajdWTo7tBrWxEbiaY",
            authDomain: "brenos-e21a0.firebaseapp.com",
            projectId: "brenos-e21a0",
            storageBucket: "brenos-e21a0.appspot.com",
            messagingSenderId: "1002515229817",
            appId: "1:1002515229817:web:8670ca974142a3059db8a8",
            measurementId: "G-7RV7KMYS1Y"));
  } else {
    await Firebase.initializeApp();
  }
}
