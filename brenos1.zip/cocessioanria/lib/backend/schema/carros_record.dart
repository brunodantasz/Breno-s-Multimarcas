import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CarrosRecord extends FirestoreRecord {
  CarrosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "nome" field.
  String? _nome;
  String get nome => _nome ?? '';
  bool hasNome() => _nome != null;

  // "marca" field.
  String? _marca;
  String get marca => _marca ?? '';
  bool hasMarca() => _marca != null;

  // "modelo" field.
  String? _modelo;
  String get modelo => _modelo ?? '';
  bool hasModelo() => _modelo != null;

  // "ano" field.
  int? _ano;
  int get ano => _ano ?? 0;
  bool hasAno() => _ano != null;

  // "cor" field.
  String? _cor;
  String get cor => _cor ?? '';
  bool hasCor() => _cor != null;

  // "quilometragem" field.
  int? _quilometragem;
  int get quilometragem => _quilometragem ?? 0;
  bool hasQuilometragem() => _quilometragem != null;

  // "imagem" field.
  String? _imagem;
  String get imagem => _imagem ?? '';
  bool hasImagem() => _imagem != null;

  // "preco" field.
  int? _preco;
  int get preco => _preco ?? 0;
  bool hasPreco() => _preco != null;

  void _initializeFields() {
    _nome = snapshotData['nome'] as String?;
    _marca = snapshotData['marca'] as String?;
    _modelo = snapshotData['modelo'] as String?;
    _ano = castToType<int>(snapshotData['ano']);
    _cor = snapshotData['cor'] as String?;
    _quilometragem = castToType<int>(snapshotData['quilometragem']);
    _imagem = snapshotData['imagem'] as String?;
    _preco = castToType<int>(snapshotData['preco']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('carros');

  static Stream<CarrosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CarrosRecord.fromSnapshot(s));

  static Future<CarrosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CarrosRecord.fromSnapshot(s));

  static CarrosRecord fromSnapshot(DocumentSnapshot snapshot) => CarrosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CarrosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CarrosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CarrosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CarrosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCarrosRecordData({
  String? nome,
  String? marca,
  String? modelo,
  int? ano,
  String? cor,
  int? quilometragem,
  String? imagem,
  int? preco,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nome': nome,
      'marca': marca,
      'modelo': modelo,
      'ano': ano,
      'cor': cor,
      'quilometragem': quilometragem,
      'imagem': imagem,
      'preco': preco,
    }.withoutNulls,
  );

  return firestoreData;
}

class CarrosRecordDocumentEquality implements Equality<CarrosRecord> {
  const CarrosRecordDocumentEquality();

  @override
  bool equals(CarrosRecord? e1, CarrosRecord? e2) {
    return e1?.nome == e2?.nome &&
        e1?.marca == e2?.marca &&
        e1?.modelo == e2?.modelo &&
        e1?.ano == e2?.ano &&
        e1?.cor == e2?.cor &&
        e1?.quilometragem == e2?.quilometragem &&
        e1?.imagem == e2?.imagem &&
        e1?.preco == e2?.preco;
  }

  @override
  int hash(CarrosRecord? e) => const ListEquality().hash([
        e?.nome,
        e?.marca,
        e?.modelo,
        e?.ano,
        e?.cor,
        e?.quilometragem,
        e?.imagem,
        e?.preco
      ]);

  @override
  bool isValidKey(Object? o) => o is CarrosRecord;
}
