package com.mycompany.cocessioanria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
